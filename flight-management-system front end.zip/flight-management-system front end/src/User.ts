export default class user{
    username!:string;
    password!:string;
   
}