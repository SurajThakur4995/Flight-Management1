import passengerDetails from "./PassengerDetails";


export default class userFlightRegistration{

pNR_Number!:number;
flightId!:number;
name!:string;
emailId!:string;
passengers!:passengerDetails[];
noOfPassenger!:number;
meal!:boolean;
typeOfMeal!:string;

}