enum TypeOfMeal{
 
    VEG,
    NONVEG,
    NONE

}