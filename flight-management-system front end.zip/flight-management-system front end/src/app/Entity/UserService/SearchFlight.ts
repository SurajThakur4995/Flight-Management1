export default class SearchFlight{

    date!:Date;
	flightId!:number;
	flightName!:string;
	flightPrice!:string;
    emailId!:string;
    pNR_Number!:string;
}