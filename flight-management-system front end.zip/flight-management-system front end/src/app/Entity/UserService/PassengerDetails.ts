export default class passengerDetails{

id!:number;
firstName!:string;
lastName!:string;
gender!:string;
age!:number;
seatNo!:string;
}