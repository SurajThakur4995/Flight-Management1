export default class UserRegistration{

    userId!:number;
	name!:string;
	email!:string;
	username!:string;
	password!:string;
}