export default class userFlightResponse{

    date!:Date;
	flightId!:number;
	flightName!:string;
	flightPrice!:string;
}