export default class userFlightRequest{

date!:Date;
fromPlace!:string;
toPlace!:string;
roundTrip!:boolean;
oneWayTrip!:boolean;

}